from django.shortcuts import render
from .models import Video, Poeme

# Vue pour la page d'accueil
def home(request):
    return render(request, 'core/home.html')

# Vue pour la page des vidéos avec gestion des filtres
def registres(request):
    videos = Video.objects.all()

    # Filtrage par langue
    langue = request.GET.get('langue')
    if langue:
        videos = videos.filter(langue=langue)

    # Filtrage par lieu
    lieu = request.GET.get('lieu')
    if lieu:
        videos = videos.filter(lieu=lieu)

    # Filtrage par musique
    musique = request.GET.get('musique')
    if musique in ['oui', 'non']:
        videos = videos.filter(musique=(musique == 'oui'))

    return render(request, 'core/registres.html', {'videos': videos})

# Vue pour la page des poèmes avec gestion des filtres
def poemes(request):
    poemes = Poeme.objects.all()

    # Filtrage par langue
    langue = request.GET.get('langue')
    if langue:
        poemes = poemes.filter(langue=langue)

    return render(request, 'core/poemes.html', {'poemes': poemes})

# Vue pour la page mémoire
def memoire(request):
    return render(request, 'core/memoire.html')

# Vue pour la page "À propos"
